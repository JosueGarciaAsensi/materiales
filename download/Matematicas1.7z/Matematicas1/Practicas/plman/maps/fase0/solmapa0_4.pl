:-use_module('pl-man-game/main').

do(drop(down)).
