:-use_module('pl-man-game/main').

do(get(up)).
do(use(up)).
