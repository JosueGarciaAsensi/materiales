:-use_module('pl-man-game/main').

do(move(down)).
