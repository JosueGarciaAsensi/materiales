/*
 * Ejercicio 3.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	int num, ndig, i=1, resul, aux1, aux2;
	
	cout<<"Introduce un numero entero: ";
	cin>>num;
	
	for(ndig=1;num/i>10;ndig++)
		i=i*10;
	
	resul=num/i;
	aux1=num%i;
	
	for(resul=resul;i>=1;i=i/10){
		
		aux2=aux1/i;
		aux1=aux1%i;
		resul=resul+aux2;
		
		}
		
	cout<<"La suma de los digitos es: "<<resul;

	return 0;
}

