/*
 * Ejercicio 3.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

void recursivo(int &, int &, char &);

int main(int argc, char **argv)
{
	int c, v;
	char sabor;
	
	do{
	cout<<"Introduce el nº de bolas de chocolate: ";
	cin>>c;
	}while(c<0);
	
	do{
	cout<<"Introduce el nº de bolas de vainilla: ";
	cin>>v;
	}while(v<0);
	
	do{
	cout<<"Que sabor empieza primero? (c/v) ";
	cin>>sabor;
	}while(sabor!='v' && sabor!='c');
	
	while(c>0 || v>0)
	recursivo(c,v,sabor);
	
	return 0;
}

void recursivo(int &c,int &v, char &s){
	
	if(s=='c'){
		if(c>0)
			cout<<"C"<<endl;
		if(v>0)
			cout<<"V"<<endl;
	}
	
	else {
		if(v>0)
			cout<<"V"<<endl;
		if(c>0)
			cout<<"C"<<endl;
	}
	
	c--;
	v--;	
}
