/*
 * Ejercicio 1.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

void nuevonum(int &, int &, int &);

int main(int argc, char **argv)
{
	int num1, num2, dig1, dig2, i=1, j=1;
	
	do{
		do{
		cout<<"Introduce un numero:";
		cin>>num1;
		if (num1<=0)
			cout<<"El numero debe ser mayor de 0.";
		}while(num1<=0);

		do{
		cout<<"Introduce otro numero:";
		cin>>num2;
		if (num2<=0)
			cout<<"El numero debe ser mayor de 0."<<endl;
		}while(num2<=0);
	
		for(dig1=1;num1/i>10;dig1++)
			i=i*10;
		for(dig2=1;num2/j>10;dig2++)
			j=j*10;
			
		if(dig1==dig2)
			nuevonum(num1,num2,i);
		else
			cout<<"ERROR,los numeros no tienen la misma cantidad de digitos"<<endl;
	}while(dig1!=dig2);
	
	return 0;
}

void nuevonum(int &n1, int &n2, int &i){
	int res1,res2;
	
	
	for(n1=n1;i>=1;i=i/10){
		
		res1=n1/i;
		res2=n2/i;
		cout<<res1<<res2;
		n1=n1%i;
		n2=n2%i;
		
	}
}
