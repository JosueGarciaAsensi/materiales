#include <iostream>
#include <time.h>
#include <stdlib.h>
using namespace std;

//Declaro 2 constantes que serán el ancho y el alto de la matriz
const int x=20;
const int y=8;

//Declaración de las funciones a utilizar
void marco(char [][y]);
void mat(char [][y]);
void escmat(char [][y]);
void comprobar(char [][y]);

//MAIN
int main(int argc, char **argv){
	
	char m[x][y], op, cont;
	
	srand((unsigned)time(NULL));
	
	do{
		
		do{
		cout<<"Quiere realizar una reserva?(s/n) ";
		cin>>op;
		}while(op!='n' && op!='s');
		
		while(op!='n'){
		
		cout<<endl<<"PATIO DE BUTACAS"<<endl<<"  ";
		marco(m);
		if(cont==0)
		mat(m);
		
		escmat(m);
	
		comprobar(m);
		
		do{
		cout<<"Desea realizar otra reserva? (s/n) ";
		cin>>op;
		}while(op!='n' && op!='s');
		
		cont++;	
		}
	}while(op!='n');
	return 0;
}

//funcion para hacer marco superior de numeros
void marco(char m[x][y]){
	int i, j, aux;
	
	j=x-1;
	aux=2;
	
	for(i=0;i<x;i++){
		if(i<10){
		if(j>11)
			cout<<j<<" ";
		else cout<<j<<"  ";
		j=j-2;}
		else{
		if(aux<8)
		cout<<aux<<"  ";
		else
		cout<<aux<<" ";
		aux=aux+2;}
	}
	
	cout<<endl;
}

//Función que proporciona valores iniciales a la matriz
void mat(char m[x][y]){
	int i, j, aux;
	
	for(j=0;j<y;j++){
		for(i=0;i<x;i++)
		m[i][j]='*';
	}
	
	aux=rand()%160;
	
	for(aux=aux;aux>0;aux--){
	i=rand()%20;
	j=rand()%8;
	m[i][j]=' ';
	}
	
}

//Función que muestra la matriz en pantalla
void escmat(char m[x][y]){
	int i,j;
	
	for(j=0;j<y;j++){
		for(i=0;i<x;i++){
		if(i==0)
			cout<<j+1<<"  ";
			cout<<m[i][j]<<"  ";}
		cout<<endl;
	}
}

//Función que comprueba la reserva
void comprobar(char m[x][y]){
	int fil, col;
	bool test;
	
	do{
	
	do{
	cout<<"Que fila desea? ";
	cin>>fil;
	if(fil>y)
	cout<<"Esa fila no existe.";
	}while(fil>y);
	
	do{
	cout<<"Que columna desea? ";
	cin>>col;
	if(col>x)
	cout<<"Esa columna no existe.";
	}while(col>x);
	
	if(col%2!=0)
	col=(19-col)/2;
	else
	col=9+col/2;
	
	if(m[col][fil-1]=='*') {
	cout<<"Reserva realizada"<<endl;
	test=true;
	m[col][fil-1]=' ';}
	
	else{
	cout<<"Error, ese sitio ya esta reservado."<<endl;
	test=false;}
	}while(!test);
}
