#include <iostream>
#include <time.h>
#include <stdlib.h>
using namespace std;

const int x=5;
const int y=5;

void mundo(char [][y]);
void juego(char [][y]);
void escmat(char [][y]);
void movimiento(char &, char [][y]);


int main(){
	char m[x][y], op, vis;
	
	srand((unsigned)time(NULL));
	
	do{
		
	do{
	cout<<"Quieres que el mundo sea visible? (s/n) ";
	cin>>vis;
	
	mundo(m);
	escmat(m);
	
	juego(m);
	
	cout<<"Quieres volver a jugar? (s/n) ";
	cin>>op;
	}while(op!='s' && op!='n');
	
	}while(op=='s');
	return 0;
}


void mundo(char m[x][y]){
	int i, j,aux;
	
	for(j=0;j<y;j++){
		for(i=0;i<x;i++){
			aux=rand()%100;
			if(aux<10)
			m[i][j]='M';
			else if(aux<20)
			m[i][j]='T';
			else
			m[i][j]='*';
			}
		}
	
	do{
	i=rand()%x;
	j=rand()%y;
	}while(i!=0 && j!=0 && i!=x && j!=y);
	
	m[i][j]='S';
	
	m[0][0]='@';
}

void juego(char m[x][y]){
	char mov;
	
	do{
	
	do{
	cout<<"Introduce el movimiento (n/s/e/o): ";
	cin>>mov;
	}while(mov!='n' && mov!='s' && mov!='e' && mov!='o');
	
	
	movimiento(mov, m);
	escmat(m);
	}while(mov!='x');
}

void escmat(char m[x][y]){
	int i,j;
	
	for(j=0;j<y;j++){
		for(i=0;i<x;i++)
			cout<<m[i][j]<<"  ";
		cout<<endl;
	}
}

void movimiento(char &mov, char m[x][y]){
	int i, j, t;
	bool salida;
	
	salida=true;
		
	for(j=0;j<y;j++){
		for(i=0;i<x;i++){
			if(salida && m[i][j]=='@'){
				if(mov=='n' && j!=0){
					if(m[i][j-1]=='S'){
						cout<<"Has salido!"<<endl;
						mov='x';}
					else if(m[i][j-1]=='T'){
						t++;
						cout<<"Has encontrado un tesoro! Ahora tienes "<<t<<" tesoro(s)"<<endl;}
					else if(m[i][j-1]=='M'){
						cout<<"Oh, has muerto..."<<endl;
						mov='x';}
					m[i][j]='*';
					m[i][j-1]='@';
					salida=false;}
				else if(mov=='s' && j!=y-1){
					if(m[i][j+1]=='S'){
						cout<<"Has salido!"<<endl;
						mov='x';}
					else if(m[i][j+1]=='T'){
						t++;
						cout<<"Has encontrado un tesoro! Ahora tienes "<<t<<" tesoro(s)"<<endl;;}
					else if(m[i][j+1]=='M'){
						cout<<"Oh, has muerto..."<<endl;
						mov='x';}
					m[i][j]='*';
					m[i][j+1]='@';
					salida=false;}
				else if(mov=='e' && i!=x-1){
					if(m[i+1][j]=='S'){
						cout<<"Has salido!"<<endl;
						mov='x';}
						else if(m[i+1][j]=='T'){
						t++;
						cout<<"Has encontrado un tesoro! Ahora tienes "<<t<<" tesoro(s)"<<endl;}
					else if(m[i+1][j]=='M'){
						cout<<"Oh, has muerto..."<<endl;
						mov='x';}
					m[i][j]='*';
					m[i+1][j]='@';
					salida=false;}
				else if(mov=='o' && i!=0){
					if(m[i-1][j]=='S'){
						cout<<"Has salido!"<<endl;
						mov='x';}
						else if(m[i-1][j]=='T'){
						t++;
						cout<<"Has encontrado un tesoro! Ahora tienes "<<t<<" tesoro(s)"<<endl;}
					else if(m[i-1][j]=='M'){
						cout<<"Oh, has muerto..."<<endl;
						mov='x';}
					m[i][j]='*';
					m[i-1][j]='@';
					salida=false;}
				else
					cout<<"Movimiento no valido."<<endl;
			}
		}
	}
}
