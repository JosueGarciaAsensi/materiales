/*
 * Ejercicio 3.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;

int main(int argc, char **argv)
{
	int n1, n2, resul, i;
	float puntos;
	char rep;
do{
	
	puntos=0;
	rep='i';
	
	for(i=0;i<5;i++){
	//Declarar numeros aleatorios
	srand((unsigned)time(NULL));
	n1=rand()%10;
	n2=rand()%10;
	
	cout<<n1<<"x"<<n2<<"=";
	cin>>resul;
	
	if(resul==n1*n2){
	cout<<"Has acertado!"<<endl;
	puntos++;}
	
	else if(resul>n1*n2){
	cout<<"Has fallado, el resultado es menor, prueba otra vez:";
	cin>>resul;
	if(resul==n1*n2){
	cout<<"Ahora has acertado!"<<endl;
	puntos=puntos+0.5;}
	else
	cout<<"Has fallado, la respuesta es:"<<n1*n2<<endl;}
	
	else {
	cout<<"Has fallado, el resultado es mayor, prueba otra vez:";
	cin>>resul;	
	if(resul==n1*n2){
	cout<<"Ahora has acertado!"<<endl;
	puntos=puntos+0.5;}
	else
	cout<<"Has fallado, la respuesta es:"<<n1*n2<<endl;}
	}
	cout<<"Tu puntuacion es de "<<puntos<<endl;
	
	while(rep!='s' && rep!='n'){
	cout<<"Quieres jugar otra vez(s/n)? ";
	cin>>rep;
	if(rep!='s' && rep!='n')
	cout<<"Respuesta no valida"<<endl;}
	
}while(rep=='s');

	return 0;
}

