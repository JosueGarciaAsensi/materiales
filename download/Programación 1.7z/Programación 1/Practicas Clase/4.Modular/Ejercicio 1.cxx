/*
 * Ejercicio 1.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;
void leepar(char &, char &, int &);
void dibuja(char &, char &, int &);
int main(int argc, char **argv)
{
	int n;
	char c1, c2;
	
	leepar(c1,c2,n);
	
	dibuja(c1,c2,n);
	
	if(c2=='R'){
	cout<<"El numero de caracteres dibujados es:"<<n*n<<endl;
	cout<<"El tamano del espacio interior es:"<<0;}
	else{
	cout<<"El numero de caracteres dibujados es:"<<n*n-(n-2)*(n-2)<<endl;
	cout<<"El tamano del espacio interior es:"<<(n-2)*(n-2);}
	
	return 0;
}
void leepar(char &c1, char &c2, int &n){
	
	cout<<"Introduce un caracter: ";
	cin>>c1;
	
	do{
	cout<<"Introduce otro caracter (R/V): ";
	cin>>c2;
	}while(c2=='R' && c2=='V');
	
	do{
	cout<<"Introduce un numero (entre 4 y 20): ";
	cin>>n;
	}while(n<4 || n>20);
	
}
void dibuja(char &c1, char &c2, int &n){
	
	int i, j;
	
	if(c2=='R'){
		for(j=1;j<=n;j++){
			for(i=1;i<=n;i++)
			cout<<c1;
		cout<<endl;
		}
	}
	else{
		for(j=1;j<=n;j++){	
			if(j==1	|| j==n){
				for(i=1;i<=n;i++)
				cout<<c1;}
				
			else{
				for(i=1;i<=n;i++){
					if(i==1 || i==n)
					cout<<c1;
					else
					cout<<" ";}
				}
		cout<<endl;
		}
	}
}	
