/*
 * Ejercicio 3.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

void operacion(int &, int &, int &, int &);

int main(int argc, char **argv)
{
	int n1, n2, resul, i,j;
	
	srand((unsigned)time(NULL));
	n1=rand()%9+1;
	
	for(i=1;i<=7;i++){
		j=0;
		operacion(n1,n2,resul,j);
		if(j==0)
		i--;}
	return 0;
}
void operacion(int &n1, int &n2, int &resul, int &j){
	
	int i;
	
	n2=rand()%9+1;
	i=rand()%4;
	
	switch(i){
		case 0: cout<<n1<<"+"<<n2<<"=";
				cin>>resul;
				if(resul==n1+n2){
				cout<<"Has acertado!"<<endl;
				j++;}
				else
				cout<<"Ups. Vuelve a intentarlo."<<endl;
				break;
		case 1: cout<<n1<<"-"<<n2<<"=";
				cin>>resul;
				if(resul==n1-n2){
				cout<<"Has acertado!"<<endl;
				j++;}
				else
				cout<<"Ups. Vuelve a intentarlo."<<endl;
				break;
		case 2: cout<<n1<<"*"<<n2<<"=";
				cin>>resul;
				if(resul==n1*n2){
				cout<<"Has acertado!"<<endl;
				j++;}
				else
				cout<<"Ups. Vuelve a intentarlo."<<endl;
				break;
		case 3: cout<<n1<<"/"<<n2<<"=";
				cin>>resul;
				if(resul==n1/n2){
				cout<<"Has acertado!"<<endl;
				j++;}
				else
				cout<<"Ups. Vuelve a intentarlo."<<endl;
				break;
		}
		n1=resul;
}
