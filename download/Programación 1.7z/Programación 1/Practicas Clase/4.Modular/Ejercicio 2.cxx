/*
 * Ejercicio 2.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

void repartecarta(int &);
void calculatotal(int &, int &);

int main(int argc, char **argv)
{
	int carta, total, banca;
	char o;
	
	srand((unsigned)time(NULL));
	banca=rand()%21+1;
	
	do{
		repartecarta(carta);
		cout<<"Te ha salido un: "<<carta<<endl;
		calculatotal(carta, total);
		cout<<"Por ahora tienes "<<total<<".  ";
		if(total<=21){
		do{
		cout<<"Quieres carta? (s/n) ";
		cin>>o;
		}while(o!='s' && o!='n');}
	}while(o=='s' && total<=21);
	
	if(total>21)
	cout<<"Te has pasado"<<endl;
	
	cout<<"La banca tenia: "<<banca<<endl;
	
	if(banca>total || total>21)
	cout<<"La banca gana.";
	else if(total>banca)
	cout<<"Has ganado.";
	else
	cout<<"Hemos empatado.";
	
	return 0;
}
void repartecarta(int &carta){
	carta=rand()%12+1;
}
void calculatotal(int &carta, int &total){
	if(carta>10)
	carta=10;
	total=total+carta;
}
