/*
 * Ejercicio 4.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	int act, sig, num, resul;
	cout<<"Introduce el canal en el que estas: ";
	cin>>act;
	cout<<"Introduce el canal al que quieres cambiar: ";
	cin>>sig;
	
	num=sig-act;
	
	if(sig>act && num<=50)
	resul=num;
	else if(sig>act && num>50)
	resul=num-99;
	else if(act>sig && num<=-50)
	resul=99+num;
	else if (act>sig && num>-50)
	resul=num;
	
	if(resul>0)
	cout<<resul<<" siguiente";
	else
	cout<<-resul<<" anterior";
	
	return 0;
}

