/*
 * Ejercicio 1.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	int alta, baja, aux;
	
	cout<<"Introduce la tension alta: ";
	cin>>alta;
	cout<<"Introduce la tension baja: ";
	cin>>baja;
	
	if(baja>alta){
	aux=baja;
	baja=alta;
	alta=aux;}
	
	if(alta<90 && baja<60)
	cout<<"Tienes hipotension.";
	else if(alta<=140 && baja<=90)
	cout<<"Tienes la tension normal.";
	else if(140<alta && alta<=160 && baja>90)
	cout<<"Tienes hipertension ligera.";
	else if(160<alta && alta<=180 && baja>=100)
	cout<<"Tienes hipertension moderada.";
	else if(alta>180 && baja>=110)
	cout<<"Tienes hipertension severa, ve al hospital.";
	else 
	cout<<"Error de lectura";
	
	return 0;
}

