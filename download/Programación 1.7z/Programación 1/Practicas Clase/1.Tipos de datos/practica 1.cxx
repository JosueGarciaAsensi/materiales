/*
 * practica 1.cxx
 * 
 * Copyright 2019 Josue Garcia Asensi <jga74@clL14-27>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <math.h>
using namespace std;

int main(int argc, char **argv)
{
	int a=3, b=2, c=-4;
	float d=1.8;
	bool resulb, resulc;
	
	
	resulb=b>c && d>a;
	resulc=(b==a) || (a>b);
	
	cout<<"Tipos de datos \nProblema 1:"<<endl;
	cout<<"a) "<<2*4/6-(10/5)<<endl;
	cout<<"b) "<<resulb<<endl;
	cout<<"c) "<<resulc<<endl;
	cout<<"d) "<<3*a-d<<endl;
	cout<<"e) "<<sqrt(d)+d/3<<endl;
	cout<<"f) "<<a%b+8*d<<endl;
	
	return 0;
}

