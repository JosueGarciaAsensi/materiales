/*
 * Matriz 5x5.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

const int KTAM=5;

void leemat(int [][KTAM]);
void escmat(int [][KTAM]);
bool essim(int [][KTAM]);

int main(int argc, char **argv)
{
	int mat[KTAM][KTAM];
	
	leemat(mat);
	escmat(mat);
	
	if(essim(mat)) //es lo mismo que essim(mat)==true
		cout<<"Es simetrica";
	else 
		cout<<"No es simetrica";
	
	return 0;
}
void leemat(int m[][KTAM]){
	int i,j;
	
	for(i=0;i<KTAM;i++){
		for(j=0;j<KTAM;j++){
			cout<<"Introduce el valor "<<i<<","<<j<<":";
			cin>>m[i][j];
		}
	}	
}

void escmat(int m[][KTAM]){
	int i,j;
	
	for(i=0;i<KTAM;i++){
		for(j=0;j<KTAM;j++)
			cout<<m[i][j]<<" ";
		cout
		<<endl;
	}
}

bool essim(int m[][KTAM]){
	int i,j;
	bool test;
	
	test=true;
	i=0;
	while(i<KTAM-1 && test){ //test==true
		j=i+1;
		while(j<KTAM-1 && test){
			if(m[i][j]!=m[j][i])
				test=false;
			j++;
		}
		i++;
	}
	return test;
}
