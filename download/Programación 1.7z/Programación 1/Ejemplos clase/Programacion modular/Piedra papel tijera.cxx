/*
 * Piedra papel tijera.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;
int apuestausuario(int n){
	do{
		cout<<"Elige 1.Piedra 2.Papel 3.Tijera";
		cin>>n;
		
		switch(n){
			case '1': cout<<"Has elegido piedra.";
					  break;
			case '2': cout<<"Has elegido papel.";
					  break;
			case '3': cout<<"Has elegido tijera.";
					  break;
			default: cout<<"Error";
					 break;
				 }
		}while(n!=1 && n!=2 && n!=3);
		
	return (n);
}
int maquina(int m){
	m=rand()%3+1;
	switch(m){
			case '1': cout<<"He elegido piedra.";
					  break;
			case '2': cout<<"He elegido papel.";
					  break;
			case '3': cout<<"He elegido tijera.";
					  break;
			default:  cout<<"Error";
					  break;
			 }
	return (m);
}
void comprobar(int n, int m, int rn, int rm){
		
	
	if(n=m)
		cout<<"Hemos empatado";
	else if((n=1 && m=2) && (n=2 && m=3) && (n=3 && m=1)){
		cout<<"Yo gano";
		rm++;}
	else {
		cout<<"Tu ganas";
		rn++;}
	cout<<"Rondas ganadas: \n maquina: "<<rm<<"\n Jugador: "<<rn;
	
}
int main(int argc, char **argv)
{
	int n, m, rn, rm, pn, pm;
	//char op;
	srand ((unsigned)time(NULL));
	
	do{
	
	n=apuestausuario(n);
	m=maquina(m);
	rn=comprobar(rn, rm);
	
	}while(rn!=2 || rm!=2);
	
	if(rn=2)
	pn++;
	if(rm=2)
	pm++;
	
	cout<<"Partidas ganadas: \n maquina: "<<pm<<"\n Jugador: "<<pn;
	
	return 0;
}

