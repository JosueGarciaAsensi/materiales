/*
 * Ej1.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

int algoritmo(int n){
	int resto; 
	char letra;
	
	resto=n%23;
	
	switch(resto){
		case '0':  letra= 'T';
		break;
		case '1':  letra= 'R';
		break;
		.......
		default: letra='X';
		break;
	}
	return (letra);
}
int main(int argc, char **argv)
{
	int dni;
	char letra;
	
	cout<<"Introduce tu numero de DNI:";
	cin>>dni;
	
	letra=algoritmo(dni);
	
	cout<<"Tu letra es: "<<letra;
	
	return 0;
}

