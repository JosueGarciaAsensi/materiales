/*
 * Libros.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

const int MAX=200;

typedef struct{
	char titulo[50];
	int isbn;
	char autor[50];
	int publicacion[3];
	int numpag;
}Tlibro;

typedef Tlibro Talmacen[MAX];

void rellelibros(Talmacen);

int main(int argc, char **argv)
{
	Talmacen lib;
	
	rellelibros(lib);
	
	return 0;
}

void rellelirbos(Talmacen libros){
	int i;
	
	for(i=0;i<MAX;i++){
		cout<<"Titulo: ";
		cin.getline(libros[i].titulo, 50);
		cout<<"ISBN: ";
		cin>>libros[i].isbn;
		cout<<"Autor: ";
		cin.getline(libros[i].autor,50);
		cout<<"Dia: ";
		cin>>libros[i].publicacion[0];
		cout<<"Mes: ";
		cin>>libros[i].publicacion[1];
		cout<<"Año: ";
		cin>>libros[i].publicacion[2];
		cout<<"Numero de paginas: ";
		cin>>libros[i].numpag;
	}
}
