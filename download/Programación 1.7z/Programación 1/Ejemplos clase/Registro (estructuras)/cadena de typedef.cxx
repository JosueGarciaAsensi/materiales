/*
 * cadena de typedef.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
using namespace std;

typedef char Tcadena[15];

typedef struct{
	Tcadena nom;
	Tcadena apellido1;
	Tcadena apellido2;
}Tnombre;

typedef struct{
	Tnombre nom;
	int num[8];
	char let;
}Tdni;

typedef struct {
	int dia;
	int mes;
	int anyo;
}Tfecha;

typedef struct{
	Tcadena nom;
	Tfecha nac;
	Tcadena cnac;
	Tcadena pnac;
}Thijo;

typedef struct{
	Tnombre nom;
	Tdni dni;
	Tfecha exp;
	Tfecha val;
	Tnombre padre;
	Tnombre madre;
	Tcadena cnac;
	Tcadena pnac;
	Tcadena cres;
	Tcadena pres;
	Thijo hijos[5];
	int numhijos;
	Tfecha nac;
}Tpersona;

typedef Tpersona Tpers90[90];

int main(int argc, char **argv)
{
	
	return 0;
}

