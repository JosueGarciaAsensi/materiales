/*
 * ejer 1.cxx
 * 
 * Copyright 2019 josue <josue@DESKTOP-HIPIB76>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <math.h>
using namespace std;

typedef struct{
	float x;
	float y;
}coordenadas;

float longitud(coordenadas, coordenadas);
float pendiente(coordenadas, coordenadas);
void leepunto (coordenadas &);
bool iguales(coordenadas, coordenadas);

int main(int argc, char **argv)
{
	coordenadas p1, p2;
	
	do{
		leepunto(p1);
		leepunto(p2);
		
		cout<<"La longitud del segmento es: "<< longitud(p1, p2)<<endl;
		
		if(p1.x!=p2.x)
			cout<<"La pendiente del segmento es: "<< pendiente(p1, p2)<<endl;
			
	}while(!iguales(p1, p2));
	
	return 0;
}

//pide datos
void leepunto(coordenadas &p){
	cout<<"Introduce la coordenada x: ";
	cin>>p.x;
	cout<<"Introduce la coordenada y: ";
	cin>>p.y;
}

//calcula longitud
float longitud(coordenadas p1, coordenadas p2){
	float resul;
	
	resul=sqrt(pow(p1.x-p2.x, 2)+pow(p1.y-p2.y, 2));
	
	return resul;
}

//calcula pendiente
float pendiente(coordenadas p1, coordenadas p2){
	int resul;
	
	resul=(p2.y-p1.y)/(p2.x-p1.x);
	
	return resul;
}

//comprueba igualdad
bool iguales(coordenadas p1, coordenadas p2){
	bool resul;
	
	if(p1.x==p2.x && p1.y==p2.y)
		resul=true;
	else 
		resul=false;
		
	return resul;
}
