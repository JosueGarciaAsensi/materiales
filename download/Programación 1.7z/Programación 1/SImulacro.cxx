#include <iostream>
using namespace std;

typedef struct{
	int num;
	char letra;
}Tingrediente;

typedef struct{
	int hora;
	int min;
}Thora;

typedef struct{
	int numped;
	char nombre[15];
	Tingrediente ingredientes;
	Thora hora;
	char enviado[10];
}Tpedido;

void menu(int &);
void nuevo(Tpedido [],int &);

int main(int argc, char **argv)
{
	int opc, n;
	Tpedido pedidos[15];
	do{
	menu(opc);
	
	if(opc==1)
		for(n=0;n<15;n++)
		nuevo(pedidos, n);
	}while(opc!=4);
	return 0;
}

void menu(int &opc){
	
		do{
			cout<<"Menu:\n 1.Introducir un nuevo pedido\n 2.Marcar un pedido como 'enviado'\n 3.Mostrar ingredientes\n 4.Salir\n";
			cin>>opc;
			if(opc<1 || opc>4)
			cout<<"Opcion no valida"<<endl;
		}while(opc<1 || opc>4);
	
}

void nuevo(Tpedido pedidos[15], int &n){
	int i;
	
	cin.get();
	pedidos[15].numped=n+1;
	cout<<"Pizza: ";
	cin.getline(pedidos[n].nombre, 15);
	cout<<"Numero de extras: ";
	cin>>pedidos[n].ingredientes.num;
	for(i=1;i<=pedidos[n].ingredientes.num;i++){
		cout<<"Ingrediente "<<i<<" :";
		cin>>pedidos[n].ingredientes.letra;}
	
}
